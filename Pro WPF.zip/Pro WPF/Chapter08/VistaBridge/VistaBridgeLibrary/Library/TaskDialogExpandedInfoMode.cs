using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.SDK.Samples.VistaBridge.Library
{
    public enum TaskDialogExpandedInformationLocation
    {
        Hide, // TODO: consider removing, we're not using it
        ExpandContent,
        ExpandFooter
    }
}
