using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.SDK.Samples.VistaBridge.Library
{
    public class TaskDialogRadioButton : TaskDialogButtonBase
    {
        public TaskDialogRadioButton() { }
        public TaskDialogRadioButton(string name, string text) : base(name, text) { }
    }
}
